window.logIn = function() {
  var displayLoginPage = {};
  var click = 'click';
  var mainContainer = $('#main-container');

  //History API code starts from here
  function historyManager(currentPage) {
    history.pushState({historyKey: currentPage}, null, "/" + currentPage);
  }

  function setLocalForageData() {
    localforage.setItem('email', 'demouser123@gmail.com');
    localforage.setItem('password', '123456');
  }
  setLocalForageData();

  function getLocalForageData(key) {
    let temp = '';
    var t = localforage.getItem(key, function(value) { return value}).then(value => {return value});
  }

  function clickEvents() {
    //Code when user click on logout button
    $('#logout').on(click, function() {
      mainContainer.empty();
      window.logIn().initialize();
    });

    //click event on timeLine
    $('#timeline').on(click, function() {
      window.timeline().initialize();
      historyManager('timeLine');
    });
    //about click event
    $('#about').on(click, function() {
      window.about().initialize();
      historyManager('aboutInfo');
    });
    //friends button click
    $('#friends').on(click, function() {
      var currentElement = $(this).attr('id');
      window.friends().initialize();
      historyManager('friends');
    });
    //display photos
    $('#photos').on(click, function() {
      window.photos().initialize();
      historyManager('photos');
    });
  }

  function displayLogIn() {
    const templateUrl = '../assets/templates/main-page.mustache';
    $.get({url: templateUrl, type: 'GET', success: function(main) {
      mainContainer.html(main);
      clickEvents();
      window.sidebar().initialize();
      window.timeline().initialize();
      historyManager('timeLine');
    }});
  }


  function formValidation() {
    $("#form-login").validate({
      submitHandler: function(form) {
        $('#login').on(click, function(event) {
          event.preventDefault();
          var newEmail = getLocalForageData('email');
          var newPswd = getLocalForageData('password');

          var email = $('#email').val();
          var pswd = $('#passwd').val();

          if (email == 'demouser123@gmail.com' & pswd == '123456' ) {
            $('.invalid-data').addClass('hidden');
            displayLogIn();
          }
          else {
            $('.invalid-data').removeClass('hidden');
          }
        });
      }
    });
  }

  function logInPage() {
    const templateUrl = '../assets/templates/login.mustache';

    $.get({url: templateUrl, type: 'GET', success: function(logInTemplate) {
      mainContainer.append(logInTemplate);
      formValidation();
    }});
  }

  displayLoginPage.initialize = function() {
    logInPage();
  }
  return displayLoginPage;
}
