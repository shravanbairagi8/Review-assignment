window.common = function() {
  var commonFunctions = {};
  var active = 'active-tab';

  function renderContent(template, element) {
    $('#main-content').html(template);
    $('.menu-content').removeClass(active);
    $('#' + element).addClass(active);
  }

  function updateName(nameId) {
    let userName = JSON.parse(localStorage.getItem('userData'));
    if (userName != null) {
      $('.' + nameId).text(userName.name);
    }
  }

  commonFunctions.initialize = function(template, element, nameId) {
    renderContent(template, element);
    updateName(nameId);
  }
  return commonFunctions;
}
